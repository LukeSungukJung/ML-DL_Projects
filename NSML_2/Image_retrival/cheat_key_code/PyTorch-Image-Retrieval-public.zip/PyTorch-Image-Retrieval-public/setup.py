from distutils.core import setup

setup(
    version='1.0',
    description='image retrieval',
    install_requires=[
        'torch==1.0.0',
        'torchvision==0.2.1',
    ]
)
